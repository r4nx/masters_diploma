#include <instruction.hpp>
#include <opcode_info.hpp>

#include <cstddef>
#include <format>
#include <stdexcept>
#include <string>
#include <utility> // std::move, std::to_underlying

constexpr raw_instruction_t mask1(std::size_t n, std::size_t p = 0)
{
    return ~(~raw_instruction_t{0} << n) << p;
}

constexpr signed_operand_t to_signed(operand_t operand, std::size_t bit_size)
{
    return static_cast<std::int64_t>(operand)
           - static_cast<std::int64_t>(mask1(bit_size - 1));
}

opcode::opcode(opcode_type op_type) : opcode{std::to_underlying(op_type)} {}

opcode::opcode(std::uint8_t op_num) : opcode_num_{op_num}
{
    if (opcode_num_ >= std::to_underlying(opcode_type::opcode_count))
        throw std::runtime_error{"Unknown opcode"};
}

opcode_type opcode::get_type() const noexcept
{
    return static_cast<opcode_type>(opcode_num_);
}

std::string_view opcode::get_name() const noexcept
{
    return opcode_info_table[opcode_num_].name;
}

op_mode opcode::get_mode() const noexcept
{
    return opcode_info_table[opcode_num_].mode;
}

raw_instruction_t instruction::get_raw() const noexcept
{
    return raw_instr_;
}

instruction::instruction(raw_instruction_t raw_instr)
    : raw_instr_{raw_instr},
      opcode_{static_cast<opcode::opcode_num_t>(get_part(opcode_part))}
{}

instruction::instruction(opcode op, operand_t a, operand_t b, operand_t c)
    : instruction{
          raw_instruction_t{std::to_underlying(op.get_type())}
          | ((a & mask1(a_part.size)) << a_part.pos)
          | ((b & mask1(b_part.size)) << b_part.pos)
          | ((c & mask1(c_part.size)) << c_part.pos)}
{}

opcode instruction::get_opcode() const noexcept
{
    return opcode_;
}

op_mode instruction::get_mode() const noexcept
{
    return opcode_.get_mode();
}

operand_t instruction::get_a() const noexcept
{
    return get_part(a_part);
}

operand_t instruction::get_b() const noexcept
{
    return get_part(b_part);
}

operand_t instruction::get_c() const noexcept
{
    return get_part(c_part);
}

signed_operand_t instruction::get_sb() const noexcept
{
    return to_signed(get_part(b_part), b_part.size);
}

signed_operand_t instruction::get_sc() const noexcept
{
    return to_signed(get_part(c_part), c_part.size);
}

operand_t instruction::get_vb() const noexcept
{
    return get_part(vb_part);
}

operand_t instruction::get_vc() const noexcept
{
    return get_part(vc_part);
}

operand_t instruction::get_bx() const noexcept
{
    return get_part(bx_part);
}

operand_t instruction::get_ax() const noexcept
{
    return get_part(ax_part);
}

signed_operand_t instruction::get_sj() const noexcept
{
    return to_signed(get_part(sj_part), sj_part.size);
}

std::string instruction::to_string(char delimiter) const
{
    std::string operands_str = [this] -> std::string {
        switch (get_mode())
        {
            case op_mode::abc:
            {
                bool signed_b = false, signed_c = false;

                switch (opcode_.get_type())
                {
                    case opcode_type::addi:
                    case opcode_type::shli:
                    case opcode_type::shri:
                        signed_c = true;
                        break;

                    case opcode_type::mmbini:
                    case opcode_type::eqi:
                    case opcode_type::lti:
                    case opcode_type::lei:
                    case opcode_type::gti:
                    case opcode_type::gei:
                        signed_b = true;

                    default:
                        break;
                }

                return std::format(
                    "{}, {}, {}",
                    get_a(),
                    signed_b ? to_signed(get_b(), b_part.size)
                             : static_cast<std::int64_t>(
                                   get_b()), // Cast to signed int since
                                             // otherwise the common type for
                                             // ternary operator is unsigned and
                                             // that's not what we need
                    signed_c ? to_signed(get_c(), c_part.size)
                             : static_cast<std::int64_t>(get_c()));
            }

            case op_mode::vabc:
                return std::format("{}, {}, {}", get_a(), get_vb(), get_vc());

            case op_mode::abx:
                return std::format("{}, {}", get_a(), get_bx());

            case op_mode::asbx:
                return std::format("{}, {}", get_a(), get_sb());

            case op_mode::ax:
                return std::format("{}", get_ax());

            case op_mode::sj:
                return std::format("{}", get_sj());

            default:
                throw std::logic_error{"Unhandled instruction mode"};
        }
    }();

    return std::string{opcode_.get_name()} + delimiter
           + std::move(operands_str);
}

raw_instruction_t instruction::get_part(const part_info &part) const noexcept
{
    return (raw_instr_ >> part.pos) & mask1(part.size);
}
