#include <instruction.hpp>
#include <lua_types.hpp>
#include <parser.hpp>

#include <cstddef>
#include <cstdint>
#include <print> // dbg
#include <string_view>
#include <utility> // std::move

eof_error::eof_error()
    : parsing_error{"Parsing failed: reached the end of the data source"}
{}

lua_bytecode_parser::lua_bytecode_parser(
    data_source *data_src,
    bool         print_debug_info)
    : data_src_{data_src},
      print_debug_info_{print_debug_info}
{}

lua_header lua_bytecode_parser::parse_header()
{
    lua_header header{};

    const std::string_view signature = "\x1bLua";
    if (parse_literal(signature.size()) != signature)
        throw parsing_error{"Lua signature mismatch"};

    const std::uint8_t version = parse_byte();
    header.version.major       = version >> 4;
    header.version.minor       = version & 0xF;

    if (header.version != lua_version{5, 5})
        throw parsing_error{"Lua version mismatch"};

    const std::uint8_t format = parse_byte();
    if (format != 0)
        throw parsing_error{"Lua bytecode format mismatch"};

    const std::string_view data = "\x19\x93\r\n\x1a\n";
    if (parse_literal(data.size()) != data)
        throw parsing_error{"Corrupted chunk"};

    const int int_test = parse_number<int>();
    if (int_test != -0x5678)
        throw parsing_error{"Int test failure"};

    const std::uint32_t instruction_test = parse_number<std::uint32_t>();
    if (instruction_test != 0x12345678)
        throw parsing_error{"Instruction test failure"};

    const std::int64_t lua_integer_test = parse_number<std::int64_t>();
    if (lua_integer_test != -0x5678)
        throw parsing_error{"Lua integer test failure"};

    const double lua_number_test = parse_number<double>();
    if (lua_number_test != -370.5)
        throw parsing_error{"Lua number test failure"};

    return header;
}

lua_function lua_bytecode_parser::parse_root_function()
{
    // Temporarily ignore closure upvalues number
    data_src_->ignore(sizeof(std::uint8_t));

    return parse_function();
}

std::unique_ptr<unsigned char[]>
lua_bytecode_parser::read(std::size_t bytes_count)
{
    auto [buf, bytes_read] = data_src_->read_data(bytes_count);

    if (bytes_read != bytes_count)
        throw eof_error{};

    // buf is not implicitly moved here since structured binding element is
    // actually a hidden reference, which are not eligible implicit move
    // https://stackoverflow.com/a/49598949
    return std::move(buf);
}

unsigned char lua_bytecode_parser::parse_byte()
{
    return read(1)[0];
}

std::string lua_bytecode_parser::parse_literal(std::size_t length)
{
    const auto buf = read(length);

    return std::string{reinterpret_cast<const char *>(buf.get()), length};
}

lua_function lua_bytecode_parser::parse_function()
{
    lua_function func{};

    const int          line_defined      = parse_leb128<int>();
    const int          last_line_defined = parse_leb128<int>();
    const std::uint8_t params_count      = parse_byte();
    const std::uint8_t fixed_code        = parse_byte();
    const std::uint8_t max_stack_size    = parse_byte();

    if (print_debug_info_)
    {
        std::println(
            "Line defined: {}, last line defined: {}",
            line_defined,
            last_line_defined);
        std::println("Parameters count: {}", params_count);
        std::println("Fixed code: {}", static_cast<unsigned>(fixed_code));
        std::println(
            "Max stack size: {}",
            static_cast<unsigned>(max_stack_size));
        std::println("Offset before code size: {}", data_src_->get_offset());
    }

    // Load code
    const int code_size = parse_leb128<int>();

    constexpr std::size_t alignment = sizeof(raw_instruction_t);
    const std::size_t     padding =
        alignment - (data_src_->get_offset() % alignment);

    if (print_debug_info_)
    {
        std::println(
            "Code size: {}, offset: {}, padding: {}",
            code_size,
            data_src_->get_offset(),
            padding);
    }

    if (padding < alignment)
        data_src_->ignore(padding);

    for (std::size_t i = 0; i < code_size; ++i)
    {
        func.instructions.emplace_back(parse_integral<raw_instruction_t>());
    }

    return func;
}
