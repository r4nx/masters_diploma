#ifndef LIDA_DEAD_CODE_DEOBFUSCATOR_HPP_
#define LIDA_DEAD_CODE_DEOBFUSCATOR_HPP_

#include <lua_types.hpp>

#include <cstddef>
#include <map>
#include <vector>

// CFG - Control Flow Graph
struct cfg_block {
    std::vector<instruction> instructions;
    bool                     reachable;
};

class dead_code_deobfuscator {
public:
    explicit dead_code_deobfuscator(const lua_function &func);

    lua_function deobfuscate();

protected:
    std::map<std::size_t, cfg_block> split_into_blocks() const;

    const lua_function &func_;
};

#endif // !LIDA_DEAD_CODE_DEOBFUSCATOR_HPP_
