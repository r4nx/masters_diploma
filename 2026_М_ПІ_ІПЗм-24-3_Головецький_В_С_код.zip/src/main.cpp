#include <dead_code_deobfuscator.hpp>
#include <move_deobfuscator.hpp>
#include <parser.hpp>
#include <reader.hpp>

#include <cxxopts.hpp>

#include <cstdio>
#include <cstdlib>
#include <exception>
#include <print>
#include <ranges> // std::views::enumerate
#include <string>

int main(int argc, char *argv[])
{
    cxxopts::Options options{"lida", "Lua disassembler and deobfuscator"};
    options.add_options()(
        "input_file",
        "Bytecode input file",
        cxxopts::value<std::string>())(
        "d,dead-code",
        "Enable dead code deobfuscator",
        cxxopts::value<bool>()->default_value("false"))(
        "m,move-chain",
        "Enable move-chain deobfuscator",
        cxxopts::value<bool>()->default_value("false"))(
        "debug",
        "Print additional debug information",
        cxxopts::value<bool>()->default_value(
            "false"))("h,help", "Print usage");

    options.parse_positional({"input_file"});
    const auto result = options.parse(argc, argv);

    if (result.count("help"))
    {
        std::println("{}", options.help());
        return EXIT_SUCCESS;
    }

    if (!result.count("input_file"))
    {
        std::println(stderr, "Error: input file is not specified");
        return EXIT_FAILURE;
    }

    try
    {
        file_data_source    data_src{result["input_file"].as<std::string>()};
        lua_bytecode_parser parser{&data_src, result["debug"].as<bool>()};

        const auto header        = parser.parse_header();
        auto       root_function = parser.parse_root_function();

        if (result["dead-code"].as<bool>())
        {
            dead_code_deobfuscator deobfuscator{root_function};
            root_function = deobfuscator.deobfuscate();
        }

        if (result["move-chain"].as<bool>())
        {
            move_deobfuscator deobfuscator{root_function};
            root_function = deobfuscator.deobfuscate();
        }

        for (const auto [i, instr] :
             std::views::enumerate(root_function.instructions)
                 | std::views::as_const)
        {
            std::println(
                "[ {:04} ] [ {:08X} ] {}",
                i,
                instr.get_raw(),
                instr.to_string());
        }
    }
    catch (const std::exception &ex)
    {
        std::println(stderr, "Error: {}", ex.what());
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
