#ifndef LIDA_MOVE_DEOBFUSCATOR_HPP_
#define LIDA_MOVE_DEOBFUSCATOR_HPP_

#include <lua_types.hpp>

class move_deobfuscator {
public:
    explicit move_deobfuscator(const lua_function &func);

    lua_function deobfuscate();

protected:
    const lua_function &func_;
};

#endif // !LIDA_MOVE_DEOBFUSCATOR_HPP_
