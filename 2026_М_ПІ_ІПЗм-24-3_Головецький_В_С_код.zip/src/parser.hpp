#ifndef LIDA_PARSER_HPP_
#define LIDA_PARSER_HPP_

#include <lua_types.hpp>
#include <reader.hpp>

#include <concepts>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <type_traits>

template <typename T>
concept primitive = std::integral<T> || std::floating_point<T>;

class parsing_error : public std::runtime_error {
public:
    using std::runtime_error::runtime_error;
};

class eof_error : public parsing_error {
public:
    eof_error();
};

class lua_bytecode_parser {
public:
    explicit lua_bytecode_parser(
        data_source *data_src,
        bool         print_debug_info = false);

    [[nodiscard]] lua_header   parse_header();
    [[nodiscard]] lua_function parse_root_function();

protected:
    [[nodiscard]] std::unique_ptr<unsigned char[]>
    read(std::size_t bytes_count);

    [[nodiscard]] unsigned char parse_byte();
    [[nodiscard]] std::string   parse_literal(std::size_t length);

    template <primitive T>
    [[nodiscard]] T parse_integral()
    {
        const auto [buf, bytes_read] =
            data_src_->read_data(sizeof(T), alignof(T));

        if (bytes_read != sizeof(T))
            throw eof_error{};

        // Cast is well-formed since creating an array of (unsigned) chars
        // implicitly starts the lifetime of implicit-lifetime types, among
        // which are scalars types. See P0593R6 for details.
        return *reinterpret_cast<const T *>(buf.get());
    }

    template <primitive T>
    [[nodiscard]] T parse_number()
    {
        const std::uint8_t number_size = parse_byte();

        if (number_size != sizeof(T))
            throw parsing_error{"Number size mismatch"};

        return parse_integral<T>();
    }

    template <std::integral T>
    [[nodiscard]] T parse_leb128()
    {
        using unsigned_t = std::make_unsigned_t<T>;

        unsigned_t   result{};
        std::uint8_t byte{};

        constexpr unsigned_t limit{std::numeric_limits<T>::max() >> 7};

        do
        {
            byte = parse_byte();

            if (result > limit)
                throw std::overflow_error{"LEB128 integer overflow"};

            result = (result << 7) | (byte & 0x7F);
        } while ((byte & 0x80) != 0);

        return static_cast<T>(result);
    }

    [[nodiscard]] lua_function parse_function();

    data_source *data_src_{};
    bool         print_debug_info_{};
};

#endif // !LIDA_PARSER_HPP_
