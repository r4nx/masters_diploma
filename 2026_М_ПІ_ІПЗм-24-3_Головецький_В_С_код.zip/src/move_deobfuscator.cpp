#include <instruction.hpp>
#include <lua_types.hpp>
#include <move_deobfuscator.hpp>
#include <opcode_info.hpp>

#include <algorithm> // std::find_if
#include <cstddef>
#include <iterator> // std::move_iterator, std::prev
#include <ranges>   // std::views::enumerate, std::views::reverse
#include <vector>

move_deobfuscator::move_deobfuscator(const lua_function &func) : func_{func} {}

lua_function move_deobfuscator::deobfuscate()
{
    std::vector<std::vector<std::size_t>> move_chains, collapsed_move_chains;

    lua_function result       = func_;
    auto        &instructions = result.instructions;

    auto collapse_move_chains = [&move_chains, &collapsed_move_chains] {
        for (auto &move_chain : move_chains)
        {
            if (move_chain.size() > 1)
                collapsed_move_chains.push_back(std::move(move_chain));
        }

        move_chains.clear();
    };

    for (const auto [instr_idx, instr] :
         std::views::enumerate(func_.instructions) | std::views::as_const)
    {
        if (instr.get_opcode().get_type() == opcode_type::move)
        {
            auto entry_it = std::ranges::find_if(
                move_chains,
                [this, &instr](const std::vector<std::size_t> &instr_indices) {
                    if (instr_indices.empty())
                        return false;

                    // Return true if last move destination equals current move
                    // source
                    return func_.instructions[instr_indices.back()].get_a()
                           == instr.get_b();
                });

            if (entry_it == move_chains.end())
            {
                move_chains.emplace_back();
                entry_it = std::prev(move_chains.end());
            }

            entry_it->push_back(instr_idx);
        }
        else
        {
            // TODO: collapse move-chains only if instruction indeed modifies
            // one of the chain's registers
            collapse_move_chains();
        }
    }

    // Do it one more time in case if instruction list ends with a move chain
    collapse_move_chains();

    for (const auto &move_chain : collapsed_move_chains | std::views::reverse)
    {
        // This should be constructed before instructions erasure because it
        // gets source and destination registers from the removed
        // instructions
        instruction new_move{
            opcode{opcode_type::move},
            instructions[move_chain.back()].get_a(),
            instructions[move_chain.front()].get_b(),
            0};

        for (const std::size_t instr_idx : move_chain | std::views::reverse)
        {
            instructions.erase(instructions.cbegin() + instr_idx);
        }

        instructions.insert(
            instructions.cbegin() + move_chain.front(),
            std::move(new_move));
    }

    return result;
}
