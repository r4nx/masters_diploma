#ifndef LIDA_LUA_TYPES_HPP_
#define LIDA_LUA_TYPES_HPP_

#include <instruction.hpp>

#include <vector>

struct lua_version {
    unsigned int major;
    unsigned int minor;

    bool operator==(const lua_version &) const = default;
};

struct lua_header {
    lua_version version;
};

struct lua_function {
    std::vector<instruction> instructions;
};

#endif // !LIDA_LUA_TYPES_HPP_
