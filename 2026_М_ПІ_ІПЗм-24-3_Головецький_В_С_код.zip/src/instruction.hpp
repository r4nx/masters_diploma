#ifndef LIDA_INSTRUCTION_HPP_
#define LIDA_INSTRUCTION_HPP_

#include <opcode_info.hpp>

#include <cstdint>
#include <string>
#include <string_view>
#include <type_traits> // std::underlying_type_t

class opcode {
public:
    using opcode_num_t = std::underlying_type_t<opcode_type>;

    explicit opcode(opcode_type op_type);

    explicit opcode(opcode_num_t op_num);

    opcode_type get_type() const noexcept;

    std::string_view get_name() const noexcept;

    op_mode get_mode() const noexcept;

private:
    opcode_num_t opcode_num_{};
};

using raw_instruction_t = std::uint32_t;
using operand_t         = std::uint32_t;
using signed_operand_t  = std::int32_t;

class instruction {
public:
    instruction(raw_instruction_t raw_instr);

    // TODO: rework getters and setters for operands, make them generic
    instruction(opcode op, operand_t a, operand_t b, operand_t c);

    raw_instruction_t get_raw() const noexcept;

    opcode get_opcode() const noexcept;

    op_mode get_mode() const noexcept;

    operand_t        get_a() const noexcept;
    operand_t        get_b() const noexcept;
    operand_t        get_c() const noexcept;
    signed_operand_t get_sb() const noexcept;
    signed_operand_t get_sc() const noexcept;
    operand_t        get_vb() const noexcept;
    operand_t        get_vc() const noexcept;
    operand_t        get_bx() const noexcept;
    operand_t        get_ax() const noexcept;
    signed_operand_t get_sj() const noexcept;

    std::string to_string(char delimiter = '\t') const;

protected:
    struct part_info {
        std::size_t pos;
        std::size_t size;
    };

    raw_instruction_t get_part(const part_info &part) const noexcept;

    static constexpr part_info opcode_part{0, 7},
        a_part{opcode_part.pos + opcode_part.size, 8},
        k_part{a_part.pos + a_part.size, 1},
        b_part{k_part.pos + k_part.size, 8},
        vb_part{k_part.pos + k_part.size, 6},
        c_part{b_part.pos + b_part.size, 8},
        vc_part{vb_part.pos + vb_part.size, 10},
        bx_part{k_part.pos, c_part.size + b_part.size + k_part.size},
        ax_part{a_part.pos, bx_part.size + a_part.size},
        sj_part{a_part.pos, bx_part.size + a_part.size};

    raw_instruction_t raw_instr_;
    opcode            opcode_;
};

#endif // !LIDA_INSTRUCTION_HPP_
