#ifndef LIDA_READER_HPP_
#define LIDA_READER_HPP_

#include <cstddef>
#include <filesystem>
#include <fstream>
#include <memory>
#include <tuple>

class data_source {
public:
    virtual ~data_source() = default;

    std::tuple<std::unique_ptr<unsigned char[]>, std::size_t> read_data(
        std::size_t bytes_count,
        std::size_t alignment = __STDCPP_DEFAULT_NEW_ALIGNMENT__);

    void ignore(std::size_t bytes_count);

    [[nodiscard]] std::size_t get_offset() const;

private:
    [[nodiscard]] virtual std::
        tuple<std::unique_ptr<unsigned char[]>, std::size_t>
        read_data_impl(std::size_t bytes_count, std::size_t alignment) = 0;

    virtual void ignore_impl(std::size_t bytes_count) = 0;

    std::size_t offset_ = 0;
};

class file_data_source : public data_source {
public:
    explicit file_data_source(const std::filesystem::path &file_path);

private:
    [[nodiscard]] std::tuple<std::unique_ptr<unsigned char[]>, std::size_t>
    read_data_impl(
        std::size_t bytes_count,
        std::size_t alignment = __STDCPP_DEFAULT_NEW_ALIGNMENT__) override;

    void ignore_impl(std::size_t bytes_count) override;

    std::ifstream file_;
};

#endif // !LIDA_READER_HPP_
