#include <dead_code_deobfuscator.hpp>
#include <instruction.hpp>
#include <lua_types.hpp>
#include <opcode_info.hpp>

#include <cstddef>
#include <format>
#include <iterator> // std::move_iterator, std::prev
#include <map>
#include <optional>
#include <ranges>
#include <set>
#include <stack>
#include <stdexcept>
#include <utility> // std::as_const, std::pair
#include <vector>

namespace {

constexpr bool is_conditional_jump(opcode_type op_type)
{
    switch (op_type)
    {
        case opcode_type::eq:
        case opcode_type::lt:
        case opcode_type::le:
        case opcode_type::eqk:
        case opcode_type::eqi:
        case opcode_type::lti:
        case opcode_type::lei:
        case opcode_type::gti:
        case opcode_type::gei:
        case opcode_type::test:
        case opcode_type::testset:
            return true;

        default:
            return false;
    }
}

std::optional<std::ptrdiff_t> get_jump_offset(const instruction &instr)
{
    const opcode_type op_type = instr.get_opcode().get_type();

    if (op_type == opcode_type::jmp)
        return instr.get_sj();
    else if (is_conditional_jump(op_type))
        return 1;
    else
        return std::nullopt;
}
} // namespace

dead_code_deobfuscator::dead_code_deobfuscator(const lua_function &func)
    : func_{func}
{}

lua_function dead_code_deobfuscator::deobfuscate()
{
    auto blocks = split_into_blocks();

    if (blocks.empty())
        return {}; // TODO: return something better?

    std::stack<std::pair<std::size_t, cfg_block *>> processing_stack;

    processing_stack.push({blocks.begin()->first, &blocks.begin()->second});

    while (!processing_stack.empty())
    {
        const auto [block_addr, block] = processing_stack.top();
        processing_stack.pop();

        block->reachable = true;

        const instruction &last_instr = block->instructions.back();
        const opcode_type  op_type    = last_instr.get_opcode().get_type();

        auto add_to_stack = [&blocks,
                             &processing_stack](std::size_t jump_target) {
            processing_stack.push({jump_target, &blocks.at(jump_target)});
        };

        const std::size_t end_addr = block_addr + block->instructions.size();

        if (op_type == opcode_type::jmp)
        {
            add_to_stack(end_addr + last_instr.get_sj());
        }
        else if (is_conditional_jump(op_type))
        {
            add_to_stack(end_addr);
            add_to_stack(end_addr + 1);
        }
        else
        {
            const std::size_t jump_target = end_addr;

            if (blocks.contains(jump_target))
                add_to_stack(jump_target);
        }
    }

    // Remove jumps over unreachable blocks
    // TODO: handle jumps in earlier blocks
    for (auto it = blocks.begin(); it != blocks.end(); ++it)
    {
        if (!it->second.reachable && it != blocks.begin())
        {
            cfg_block &previous_block = std::prev(it)->second;

            if (previous_block.instructions.back().get_opcode().get_type()
                == opcode_type::jmp)
            {
                previous_block.instructions.pop_back();
            }
        }
    }

    lua_function func;
    for (auto &[_, block] : blocks)
    {
        if (!block.reachable)
            continue;

        func.instructions.insert(
            func.instructions.cend(),
            std::move_iterator{block.instructions.begin()},
            std::move_iterator{block.instructions.end()});
    }

    return func;
}

std::map<std::size_t, cfg_block>
dead_code_deobfuscator::split_into_blocks() const
{
    const auto &instructions = func_.instructions;

    // Leaders list must be sorted and the elements must be unique, so using
    // std::set instead of std::vector is required here
    std::set<std::size_t> leaders_indices{0};

    for (const auto [index, instr] : std::views::enumerate(instructions))
    {
        const opcode_type op_type = instr.get_opcode().get_type();

        auto is_jump_within_bounds =
            [index, &instructions = std::as_const(instructions)](
                std::ptrdiff_t offset) {
                if (offset < 0)
                    return index + 1 + offset >= 0;
                else
                    return index + 1 + offset < instructions.size();
            };

        // Jump target is relative to the end of jump instruction and is
        // measured in instructions count
        const auto offset = get_jump_offset(instr);

        if (!offset)
            // Instruction is not a jump
            continue;

        // If current instruction is not last..
        if (index + 1 < instructions.size())
        {
            // .. then add next instruction to the leaders list
            leaders_indices.insert(index + 1);
        }

        // Add jump target to the leaders list
        // TODO: handle JMP 0
        if (!is_jump_within_bounds(*offset))
            throw std::runtime_error{std::format(
                "Jump destination is out of bounds (index + 1 = {}, "
                "offset = {})",
                index + 1,
                *offset)};

        leaders_indices.insert(index + 1 + *offset);
    }

    std::map<std::size_t, cfg_block> blocks;

    auto leader_it = leaders_indices.cbegin();
    auto block_it  = blocks.begin();

    for (std::size_t i = 0; i < instructions.size(); ++i)
    {
        if (leader_it != leaders_indices.cend() && i == *leader_it)
        {
            // Create new block if leader is found
            block_it = blocks.try_emplace(block_it, i);
            ++leader_it;
        }

        block_it->second.instructions.push_back(instructions[i]);
    }

    return blocks;
}
