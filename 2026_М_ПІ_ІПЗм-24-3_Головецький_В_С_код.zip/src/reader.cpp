#include <reader.hpp>

#include <format>
#include <ios> // std::ios_base
#include <memory>
#include <new>
#include <stdexcept>
#include <utility> // std::move

std::tuple<std::unique_ptr<unsigned char[]>, std::size_t>
data_source::read_data(std::size_t bytes_count, std::size_t alignment)
{
    auto [buf, bytes_read] = read_data_impl(bytes_count, alignment);
    offset_ += bytes_read;

    return {std::move(buf), bytes_read};
}

void data_source::ignore(std::size_t bytes_count)
{
    ignore_impl(bytes_count);
    offset_ += bytes_count;
}

std::size_t data_source::get_offset() const
{
    return offset_;
}

file_data_source::file_data_source(const std::filesystem::path &file_path)
    : file_{file_path, std::ios_base::binary}
{
    if (!file_)
        throw std::runtime_error{
            std::format("Failed to open file {}", file_path.string())};
}

std::tuple<std::unique_ptr<unsigned char[]>, std::size_t>
file_data_source::read_data_impl(std::size_t bytes_count, std::size_t alignment)
{
    auto buf = [bytes_count, alignment] {
        if (alignment > __STDCPP_DEFAULT_NEW_ALIGNMENT__)
            return std::unique_ptr<unsigned char[]>{
                new (std::align_val_t{alignment}) unsigned char[bytes_count]};
        else
            return std::make_unique<unsigned char[]>(bytes_count);
    }();

    file_.read(reinterpret_cast<char *>(buf.get()), bytes_count);

    if (!file_.good())
    {
        if (file_.eof())
        {
            // Return smaller buffer in case if there are not enough bytes in
            // the file
            return {std::move(buf), file_.gcount()};
        }
        else
            throw std::runtime_error{"Failed to read data from file"};
    }

    return {std::move(buf), bytes_count};
}

void file_data_source::ignore_impl(std::size_t bytes_count)
{
    file_.ignore(bytes_count);
}
